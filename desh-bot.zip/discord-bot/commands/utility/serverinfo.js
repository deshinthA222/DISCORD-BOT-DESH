const { SlashCommandBuilder } = require("discord.js");
const { baseEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder().setName("serverinfo").setDescription("Show info about this server"),

  async execute(interaction) {
    const guild = interaction.guild;
    const owner = await guild.fetchOwner();

    const embed = baseEmbed()
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ size: 256 }))
      .addFields(
        { name: "Owner", value: `${owner.user.tag}`, inline: true },
        { name: "Members", value: `${guild.memberCount}`, inline: true },
        { name: "Created", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
        { name: "Channels", value: `${guild.channels.cache.size}`, inline: true },
        { name: "Roles", value: `${guild.roles.cache.size}`, inline: true },
        { name: "Boost Tier", value: `${guild.premiumTier}`, inline: true }
      );

    return interaction.reply({ embeds: [embed] });
  }
};
