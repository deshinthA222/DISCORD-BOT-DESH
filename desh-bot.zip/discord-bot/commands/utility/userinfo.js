const { SlashCommandBuilder } = require("discord.js");
const { baseEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Show info about a member")
    .addUserOption((o) => o.setName("user").setDescription("Member to inspect")),

  async execute(interaction) {
    const user = interaction.options.getUser("user") || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    const embed = baseEmbed()
      .setTitle(user.tag)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: "User ID", value: user.id, inline: true },
        { name: "Account Created", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>`, inline: true }
      );

    if (member) {
      embed.addFields(
        { name: "Joined Server", value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`, inline: true },
        {
          name: "Roles",
          value: member.roles.cache.filter((r) => r.id !== interaction.guild.id).map((r) => `${r}`).join(", ") || "None"
        }
      );
    }

    return interaction.reply({ embeds: [embed] });
  }
};
