const { SlashCommandBuilder } = require("discord.js");
const { baseEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("avatar")
    .setDescription("Show a member's avatar")
    .addUserOption((o) => o.setName("user").setDescription("Member to inspect")),

  async execute(interaction) {
    const user = interaction.options.getUser("user") || interaction.user;
    const embed = baseEmbed()
      .setTitle(`${user.tag}'s avatar`)
      .setImage(user.displayAvatarURL({ size: 1024 }));

    return interaction.reply({ embeds: [embed] });
  }
};
