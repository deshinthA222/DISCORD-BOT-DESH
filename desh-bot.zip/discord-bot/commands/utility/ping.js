const { SlashCommandBuilder } = require("discord.js");
const { infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder().setName("ping").setDescription("Check the bot's latency"),

  async execute(interaction, client) {
    const sent = await interaction.reply({ embeds: [infoEmbed("🏓 Pinging...")], fetchReply: true });
    const roundTrip = sent.createdTimestamp - interaction.createdTimestamp;

    return interaction.editReply({
      embeds: [infoEmbed(`🏓 **Pong!**\nRoundtrip: \`${roundTrip}ms\`\nWebSocket: \`${client.ws.ping}ms\``)]
    });
  }
};
