const { SlashCommandBuilder } = require("discord.js");
const db = require("../../database/db");
const { infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder().setName("leaderboard").setDescription("Show the server's XP leaderboard"),

  async execute(interaction) {
    const rows = db
      .prepare("SELECT * FROM levels WHERE guild_id = ? ORDER BY xp DESC LIMIT 10")
      .all(interaction.guild.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed("No one has earned XP yet.")] });
    }

    const medals = ["🥇", "🥈", "🥉"];
    const list = rows
      .map((r, i) => `${medals[i] || `**${i + 1}.**`} <@${r.user_id}> — Level ${r.level} (${r.xp} XP)`)
      .join("\n");

    return interaction.reply({ embeds: [infoEmbed(`**🏆 XP Leaderboard**\n\n${list}`)] });
  }
};
