const { SlashCommandBuilder } = require("discord.js");
const db = require("../../database/db");
const { baseEmbed, infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rank")
    .setDescription("Show your (or another member's) level and XP")
    .addUserOption((o) => o.setName("user").setDescription("Member to check")),

  async execute(interaction) {
    const user = interaction.options.getUser("user") || interaction.user;
    const row = db
      .prepare("SELECT * FROM levels WHERE guild_id = ? AND user_id = ?")
      .get(interaction.guild.id, user.id);

    if (!row) {
      return interaction.reply({ embeds: [infoEmbed(`${user} hasn't earned any XP yet.`)] });
    }

    const nextLevelXp = 5 * row.level * row.level + 50 * row.level + 100;

    const embed = baseEmbed()
      .setTitle(`${user.tag}'s Rank`)
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: "Level", value: `${row.level}`, inline: true },
        { name: "XP", value: `${row.xp} / ${nextLevelXp}`, inline: true }
      );

    return interaction.reply({ embeds: [embed] });
  }
};
