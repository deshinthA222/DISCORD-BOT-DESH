const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../database/db");
const { successEmbed, errorEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("reactionrole-add")
    .setDescription("Bind an emoji reaction on a message to a role")
    .addStringOption((o) => o.setName("message_id").setDescription("Target message ID").setRequired(true))
    .addStringOption((o) => o.setName("emoji").setDescription("Emoji to react with").setRequired(true))
    .addRoleOption((o) => o.setName("role").setDescription("Role to grant").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const messageId = interaction.options.getString("message_id");
    const emoji = interaction.options.getString("emoji");
    const role = interaction.options.getRole("role");

    const message = await interaction.channel.messages.fetch(messageId).catch(() => null);
    if (!message) {
      return interaction.reply({ embeds: [errorEmbed("Couldn't find that message in this channel.")], ephemeral: true });
    }

    await message.react(emoji).catch(() => {
      return interaction.reply({ embeds: [errorEmbed("Invalid emoji — make sure the bot can use it.")], ephemeral: true });
    });

    db.prepare(
      "INSERT INTO reaction_roles (guild_id, message_id, emoji, role_id) VALUES (?, ?, ?, ?)"
    ).run(interaction.guild.id, messageId, emoji, role.id);

    return interaction.reply({
      embeds: [successEmbed(`Reacting with ${emoji} on that message now grants ${role}.`)],
      ephemeral: true
    });
  }
};
