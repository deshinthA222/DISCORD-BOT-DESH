const { SlashCommandBuilder } = require("discord.js");
const { infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("dice")
    .setDescription("Roll a dice")
    .addIntegerOption((o) => o.setName("sides").setDescription("Number of sides (default 6)").setMinValue(2).setMaxValue(1000)),

  async execute(interaction) {
    const sides = interaction.options.getInteger("sides") || 6;
    const roll = Math.floor(Math.random() * sides) + 1;
    return interaction.reply({ embeds: [infoEmbed(`🎲 You rolled a **${roll}** (d${sides})`)] });
  }
};
