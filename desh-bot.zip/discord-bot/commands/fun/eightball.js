const { SlashCommandBuilder } = require("discord.js");
const { infoEmbed } = require("../../utils/embeds");

const ANSWERS = [
  "It is certain.", "Without a doubt.", "Yes, definitely.", "You may rely on it.",
  "Most likely.", "Outlook good.", "Signs point to yes.", "Reply hazy, try again.",
  "Ask again later.", "Better not tell you now.", "Cannot predict now.",
  "Don't count on it.", "My reply is no.", "Outlook not so good.", "Very doubtful."
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName("8ball")
    .setDescription("Ask the magic 8-ball a question")
    .addStringOption((o) => o.setName("question").setDescription("Your question").setRequired(true)),

  async execute(interaction) {
    const question = interaction.options.getString("question");
    const answer = ANSWERS[Math.floor(Math.random() * ANSWERS.length)];

    return interaction.reply({
      embeds: [infoEmbed(`🎱 **Q:** ${question}\n**A:** ${answer}`)]
    });
  }
};
