const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../database/db");
const { successEmbed } = require("../../utils/embeds");

function ensureRow(guildId) {
  db.prepare("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)").run(guildId);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("settings")
    .setDescription("Configure server settings")
    .addSubcommand((sub) =>
      sub
        .setName("autorole")
        .setDescription("Set the role auto-assigned to new members")
        .addRoleOption((o) => o.setName("role").setDescription("Role to auto-assign").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("welcome")
        .setDescription("Set the welcome channel and message")
        .addChannelOption((o) => o.setName("channel").setDescription("Welcome channel").setRequired(true))
        .addStringOption((o) =>
          o.setName("message").setDescription("Use {user} and {server} as placeholders").setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("goodbye")
        .setDescription("Set the goodbye channel and message")
        .addChannelOption((o) => o.setName("channel").setDescription("Goodbye channel").setRequired(true))
        .addStringOption((o) =>
          o.setName("message").setDescription("Use {user} and {server} as placeholders").setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("modlog")
        .setDescription("Set the moderation log channel")
        .addChannelOption((o) => o.setName("channel").setDescription("Mod log channel").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("joinlog")
        .setDescription("Set the join/leave log channel")
        .addChannelOption((o) => o.setName("channel").setDescription("Join log channel").setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    ensureRow(guildId);

    if (sub === "autorole") {
      const role = interaction.options.getRole("role");
      db.prepare("UPDATE guild_settings SET autorole_id = ? WHERE guild_id = ?").run(role.id, guildId);
      return interaction.reply({ embeds: [successEmbed(`Autorole set to ${role}.`)] });
    }

    if (sub === "welcome") {
      const channel = interaction.options.getChannel("channel");
      const message = interaction.options.getString("message");
      db.prepare(
        "UPDATE guild_settings SET welcome_channel_id = ?, welcome_message = COALESCE(?, welcome_message) WHERE guild_id = ?"
      ).run(channel.id, message, guildId);
      return interaction.reply({ embeds: [successEmbed(`Welcome messages will be sent in ${channel}.`)] });
    }

    if (sub === "goodbye") {
      const channel = interaction.options.getChannel("channel");
      const message = interaction.options.getString("message");
      db.prepare(
        "UPDATE guild_settings SET goodbye_channel_id = ?, goodbye_message = COALESCE(?, goodbye_message) WHERE guild_id = ?"
      ).run(channel.id, message, guildId);
      return interaction.reply({ embeds: [successEmbed(`Goodbye messages will be sent in ${channel}.`)] });
    }

    if (sub === "modlog") {
      const channel = interaction.options.getChannel("channel");
      db.prepare("UPDATE guild_settings SET mod_log_channel_id = ? WHERE guild_id = ?").run(channel.id, guildId);
      return interaction.reply({ embeds: [successEmbed(`Moderation logs will be sent in ${channel}.`)] });
    }

    if (sub === "joinlog") {
      const channel = interaction.options.getChannel("channel");
      db.prepare("UPDATE guild_settings SET join_log_channel_id = ? WHERE guild_id = ?").run(channel.id, guildId);
      return interaction.reply({ embeds: [successEmbed(`Join/leave logs will be sent in ${channel}.`)] });
    }
  }
};
