const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const db = require("../../database/db");
const { baseEmbed, errorEmbed } = require("../../utils/embeds");

const UNIT_MS = { m: 60000, h: 3600000, d: 86400000 };

function parseDuration(input) {
  const match = /^(\d+)([mhd])$/.exec(input.trim());
  if (!match) return null;
  return parseInt(match[1], 10) * UNIT_MS[match[2]];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("gstart")
    .setDescription("Start a giveaway")
    .addStringOption((o) => o.setName("duration").setDescription("e.g. 10m, 1h, 1d").setRequired(true))
    .addStringOption((o) => o.setName("prize").setDescription("What are you giving away?").setRequired(true))
    .addIntegerOption((o) => o.setName("winners").setDescription("Number of winners").setMinValue(1).setMaxValue(20))
    .addRoleOption((o) => o.setName("required_role").setDescription("Role required to enter"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const durationStr = interaction.options.getString("duration");
    const prize = interaction.options.getString("prize");
    const winnersCount = interaction.options.getInteger("winners") || 1;
    const requiredRole = interaction.options.getRole("required_role");

    const ms = parseDuration(durationStr);
    if (!ms) {
      return interaction.reply({
        embeds: [errorEmbed("Invalid duration. Use formats like `10m`, `2h`, `1d`.")],
        ephemeral: true
      });
    }

    const endsAt = Date.now() + ms;
    const embed = baseEmbed()
      .setTitle(`🎁 ${prize}`)
      .setDescription(
        `Click 🎉 to enter!\nEnds: <t:${Math.floor(endsAt / 1000)}:R>\nWinners: **${winnersCount}**\nHosted by: ${interaction.user}` +
          (requiredRole ? `\nRequired role: ${requiredRole}` : "")
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("giveaway:enter").setLabel("Enter (0)").setStyle(ButtonStyle.Success).setEmoji("🎉")
    );

    const message = await interaction.channel.send({ embeds: [embed], components: [row] });

    db.prepare(
      `INSERT INTO giveaways (guild_id, channel_id, message_id, prize, winners_count, host_id, ends_at, required_role_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      interaction.guild.id,
      interaction.channel.id,
      message.id,
      prize,
      winnersCount,
      interaction.user.id,
      endsAt,
      requiredRole?.id || null
    );

    return interaction.reply({ content: "Giveaway started!", ephemeral: true });
  }
};
