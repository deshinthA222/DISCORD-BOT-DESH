const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../database/db");
const { endGiveaway } = require("../../utils/giveaway");
const { errorEmbed, successEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("gend")
    .setDescription("End a giveaway early and pick winners")
    .addStringOption((o) => o.setName("message_id").setDescription("Giveaway message ID").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction, client) {
    const messageId = interaction.options.getString("message_id");
    const giveaway = db
      .prepare("SELECT * FROM giveaways WHERE message_id = ? AND ended = 0")
      .get(messageId);

    if (!giveaway) {
      return interaction.reply({ embeds: [errorEmbed("No active giveaway found with that message ID.")], ephemeral: true });
    }

    await endGiveaway(client, giveaway);
    return interaction.reply({ embeds: [successEmbed("Giveaway ended.")], ephemeral: true });
  }
};
