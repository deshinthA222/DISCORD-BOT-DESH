const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../database/db");
const { errorEmbed, infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("greroll")
    .setDescription("Reroll a winner for an ended giveaway")
    .addStringOption((o) => o.setName("message_id").setDescription("Giveaway message ID").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const messageId = interaction.options.getString("message_id");
    const giveaway = db.prepare("SELECT * FROM giveaways WHERE message_id = ?").get(messageId);

    if (!giveaway) {
      return interaction.reply({ embeds: [errorEmbed("No giveaway found with that message ID.")], ephemeral: true });
    }

    const entries = db
      .prepare("SELECT user_id FROM giveaway_entries WHERE giveaway_id = ?")
      .all(giveaway.id);

    if (entries.length === 0) {
      return interaction.reply({ embeds: [errorEmbed("No entries to reroll from.")], ephemeral: true });
    }

    const winner = entries[Math.floor(Math.random() * entries.length)].user_id;

    await interaction.reply({
      embeds: [infoEmbed(`🎉 New winner for **${giveaway.prize}**: <@${winner}>!`)]
    });
  }
};
