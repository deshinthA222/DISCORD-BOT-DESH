const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const { baseEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket-panel")
    .setDescription("Post a support ticket panel in this channel")
    .addStringOption((o) => o.setName("title").setDescription("Panel title").setRequired(false))
    .addStringOption((o) => o.setName("description").setDescription("Panel description").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const title = interaction.options.getString("title") || "🎫 Support Tickets";
    const description =
      interaction.options.getString("description") ||
      "Click the button below to open a private support ticket.";

    const embed = baseEmbed().setTitle(title).setDescription(description);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("ticket:open").setLabel("Open Ticket").setStyle(ButtonStyle.Primary).setEmoji("🎫")
    );

    await interaction.channel.send({ embeds: [embed], components: [row] });
    return interaction.reply({ content: "Ticket panel posted.", ephemeral: true });
  }
};
