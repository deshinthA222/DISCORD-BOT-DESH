const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../database/db");
const { successEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member")
    .addUserOption((o) => o.setName("user").setDescription("Member to warn").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for the warning").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");

    db.prepare(
      "INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?, ?)"
    ).run(interaction.guild.id, target.id, interaction.user.id, reason, Date.now());

    const count = db
      .prepare("SELECT COUNT(*) AS c FROM warnings WHERE guild_id = ? AND user_id = ?")
      .get(interaction.guild.id, target.id).c;

    return interaction.reply({
      embeds: [successEmbed(`**${target.tag}** was warned.\n**Reason:** ${reason}\n**Total warnings:** ${count}`)]
    });
  }
};
