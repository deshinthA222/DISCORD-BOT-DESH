const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { successEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("Unlock this channel so @everyone can send messages again")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
      SendMessages: null
    });

    return interaction.reply({ embeds: [successEmbed("🔓 Channel unlocked.")] });
  }
};
