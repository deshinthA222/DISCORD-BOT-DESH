const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { successEmbed, errorEmbed } = require("../../utils/embeds");
const { canModerate } = require("../../utils/permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member from the server")
    .addUserOption((o) => o.setName("user").setDescription("Member to kick").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for the kick"))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason") || "No reason provided";
    const targetMember = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed("That user is not in this server.")], ephemeral: true });
    }
    if (!canModerate(interaction.member, targetMember)) {
      return interaction.reply({
        embeds: [errorEmbed("You cannot kick this member (role hierarchy or invalid target).")],
        ephemeral: true
      });
    }

    await targetMember.kick(`${reason} | by ${interaction.user.tag}`);

    return interaction.reply({
      embeds: [successEmbed(`**${target.tag}** was kicked.\n**Reason:** ${reason}`)]
    });
  }
};
