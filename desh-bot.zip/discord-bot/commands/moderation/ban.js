const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { successEmbed, errorEmbed } = require("../../utils/embeds");
const { canModerate } = require("../../utils/permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban a member from the server")
    .addUserOption((o) => o.setName("user").setDescription("Member to ban").setRequired(true))
    .addStringOption((o) => o.setName("reason").setDescription("Reason for the ban"))
    .addIntegerOption((o) =>
      o.setName("delete_days").setDescription("Days of messages to delete (0-7)").setMinValue(0).setMaxValue(7)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason") || "No reason provided";
    const deleteDays = interaction.options.getInteger("delete_days") || 0;

    const targetMember = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (targetMember && !canModerate(interaction.member, targetMember)) {
      return interaction.reply({
        embeds: [errorEmbed("You cannot ban this member (role hierarchy or invalid target).")],
        ephemeral: true
      });
    }

    await interaction.guild.members.ban(target.id, {
      deleteMessageSeconds: deleteDays * 86400,
      reason: `${reason} | by ${interaction.user.tag}`
    });

    return interaction.reply({
      embeds: [successEmbed(`**${target.tag}** was banned.\n**Reason:** ${reason}`)]
    });
  }
};
