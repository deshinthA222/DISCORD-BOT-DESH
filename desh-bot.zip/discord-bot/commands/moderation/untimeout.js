const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { successEmbed, errorEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("untimeout")
    .setDescription("Remove a timeout from a member")
    .addUserOption((o) => o.setName("user").setDescription("Member to untimeout").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const targetMember = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed("That user is not in this server.")], ephemeral: true });
    }

    await targetMember.timeout(null, `Timeout removed by ${interaction.user.tag}`);

    return interaction.reply({ embeds: [successEmbed(`**${target.tag}**'s timeout was removed.`)] });
  }
};
