const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const db = require("../../database/db");
const { infoEmbed, successEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("View or clear a member's warning history")
    .addSubcommand((sub) =>
      sub
        .setName("view")
        .setDescription("View a member's warnings")
        .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName("clear")
        .setDescription("Clear a member's warnings")
        .addUserOption((o) => o.setName("user").setDescription("Member").setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser("user");

    if (sub === "clear") {
      db.prepare("DELETE FROM warnings WHERE guild_id = ? AND user_id = ?").run(
        interaction.guild.id,
        target.id
      );
      return interaction.reply({ embeds: [successEmbed(`Cleared all warnings for **${target.tag}**.`)] });
    }

    const rows = db
      .prepare("SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC")
      .all(interaction.guild.id, target.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed(`**${target.tag}** has no warnings.`)] });
    }

    const list = rows
      .slice(0, 10)
      .map(
        (w, i) =>
          `**${i + 1}.** ${w.reason} — <t:${Math.floor(w.created_at / 1000)}:R> (by <@${w.moderator_id}>)`
      )
      .join("\n");

    return interaction.reply({
      embeds: [infoEmbed(`**Warnings for ${target.tag}** (${rows.length} total)\n\n${list}`)]
    });
  }
};
