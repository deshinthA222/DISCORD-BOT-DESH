const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { successEmbed, errorEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("purge")
    .setDescription("Bulk delete messages in this channel")
    .addIntegerOption((o) =>
      o.setName("amount").setDescription("Number of messages (1-100)").setMinValue(1).setMaxValue(100).setRequired(true)
    )
    .addUserOption((o) => o.setName("user").setDescription("Only delete messages from this user"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger("amount");
    const user = interaction.options.getUser("user");

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const filtered = user ? messages.filter((m) => m.author.id === user.id) : messages;
    const toDelete = [...filtered.values()].slice(0, amount);

    if (toDelete.length === 0) {
      return interaction.editReply({ embeds: [errorEmbed("No matching messages found.")] });
    }

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => null);
    if (!deleted) {
      return interaction.editReply({
        embeds: [errorEmbed("Failed to delete messages (likely older than 14 days).")]
      });
    }

    return interaction.editReply({ embeds: [successEmbed(`Deleted **${deleted.size}** messages.`)] });
  }
};
