const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const { successEmbed, errorEmbed } = require("../../utils/embeds");
const { canModerate } = require("../../utils/permissions");

const UNIT_MS = { m: 60000, h: 3600000, d: 86400000 };

function parseDuration(input) {
  const match = /^(\d+)([mhd])$/.exec(input.trim());
  if (!match) return null;
  return parseInt(match[1], 10) * UNIT_MS[match[2]];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Timeout (mute) a member for a duration")
    .addUserOption((o) => o.setName("user").setDescription("Member to timeout").setRequired(true))
    .addStringOption((o) =>
      o.setName("duration").setDescription("e.g. 10m, 1h, 1d").setRequired(true)
    )
    .addStringOption((o) => o.setName("reason").setDescription("Reason for the timeout"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser("user");
    const durationStr = interaction.options.getString("duration");
    const reason = interaction.options.getString("reason") || "No reason provided";

    const ms = parseDuration(durationStr);
    if (!ms || ms > 28 * 86400000) {
      return interaction.reply({
        embeds: [errorEmbed("Invalid duration. Use formats like `10m`, `2h`, `1d` (max 28d).")],
        ephemeral: true
      });
    }

    const targetMember = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!targetMember) {
      return interaction.reply({ embeds: [errorEmbed("That user is not in this server.")], ephemeral: true });
    }
    if (!canModerate(interaction.member, targetMember)) {
      return interaction.reply({
        embeds: [errorEmbed("You cannot timeout this member (role hierarchy or invalid target).")],
        ephemeral: true
      });
    }

    await targetMember.timeout(ms, `${reason} | by ${interaction.user.tag}`);

    return interaction.reply({
      embeds: [successEmbed(`**${target.tag}** was timed out for **${durationStr}**.\n**Reason:** ${reason}`)]
    });
  }
};
