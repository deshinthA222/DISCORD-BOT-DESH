const { SlashCommandBuilder } = require("discord.js");
const db = require("../../database/db");
const config = require("../../config");
const { getAccount } = require("../../utils/economy");
const { successEmbed, errorEmbed } = require("../../utils/embeds");

const DAY_MS = 86400000;

module.exports = {
  data: new SlashCommandBuilder().setName("daily").setDescription("Claim your daily reward"),

  async execute(interaction) {
    const account = getAccount(interaction.guild.id, interaction.user.id);
    const now = Date.now();

    if (now - account.last_daily < DAY_MS) {
      const remaining = DAY_MS - (now - account.last_daily);
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      return interaction.reply({
        embeds: [errorEmbed(`You already claimed your daily reward. Try again in **${hours}h ${minutes}m**.`)],
        ephemeral: true
      });
    }

    db.prepare(
      "UPDATE economy SET balance = balance + ?, last_daily = ? WHERE guild_id = ? AND user_id = ?"
    ).run(config.economy.dailyAmount, now, interaction.guild.id, interaction.user.id);

    return interaction.reply({
      embeds: [successEmbed(`You claimed your daily reward of **${config.economy.dailyAmount}** coins!`)]
    });
  }
};
