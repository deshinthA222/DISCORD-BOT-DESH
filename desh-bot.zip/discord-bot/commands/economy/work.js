const { SlashCommandBuilder } = require("discord.js");
const db = require("../../database/db");
const config = require("../../config");
const { getAccount } = require("../../utils/economy");
const { successEmbed, errorEmbed } = require("../../utils/embeds");

const COOLDOWN_MS = 3600000; // 1 hour
const JOBS = [
  "delivered packages", "streamed for a few hours", "fixed a bug in production",
  "walked some dogs", "modded a Discord server", "sold rare in-game items"
];

module.exports = {
  data: new SlashCommandBuilder().setName("work").setDescription("Work to earn coins"),

  async execute(interaction) {
    const account = getAccount(interaction.guild.id, interaction.user.id);
    const now = Date.now();

    if (now - account.last_work < COOLDOWN_MS) {
      const remainingMin = Math.ceil((COOLDOWN_MS - (now - account.last_work)) / 60000);
      return interaction.reply({
        embeds: [errorEmbed(`You're tired. Rest for **${remainingMin} more minute(s)** before working again.`)],
        ephemeral: true
      });
    }

    const { workMin, workMax } = config.economy;
    const earned = Math.floor(Math.random() * (workMax - workMin + 1)) + workMin;
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];

    db.prepare(
      "UPDATE economy SET balance = balance + ?, last_work = ? WHERE guild_id = ? AND user_id = ?"
    ).run(earned, now, interaction.guild.id, interaction.user.id);

    return interaction.reply({
      embeds: [successEmbed(`You ${job} and earned **${earned}** coins!`)]
    });
  }
};
