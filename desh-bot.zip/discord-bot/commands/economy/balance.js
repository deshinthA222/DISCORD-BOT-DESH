const { SlashCommandBuilder } = require("discord.js");
const { getAccount } = require("../../utils/economy");
const { infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("balance")
    .setDescription("Check your (or another member's) balance")
    .addUserOption((o) => o.setName("user").setDescription("Member to check")),

  async execute(interaction) {
    const user = interaction.options.getUser("user") || interaction.user;
    const account = getAccount(interaction.guild.id, user.id);

    return interaction.reply({
      embeds: [
        infoEmbed(
          `💰 **${user.tag}'s Balance**\nWallet: **${account.balance}** coins\nBank: **${account.bank}** coins`
        )
      ]
    });
  }
};
