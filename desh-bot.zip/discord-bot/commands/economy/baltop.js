const { SlashCommandBuilder } = require("discord.js");
const db = require("../../database/db");
const { infoEmbed } = require("../../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder().setName("baltop").setDescription("Show the richest members in this server"),

  async execute(interaction) {
    const rows = db
      .prepare("SELECT * FROM economy WHERE guild_id = ? ORDER BY (balance + bank) DESC LIMIT 10")
      .all(interaction.guild.id);

    if (rows.length === 0) {
      return interaction.reply({ embeds: [infoEmbed("No one has any coins yet.")] });
    }

    const medals = ["🥇", "🥈", "🥉"];
    const list = rows
      .map((r, i) => `${medals[i] || `**${i + 1}.**`} <@${r.user_id}> — ${r.balance + r.bank} coins`)
      .join("\n");

    return interaction.reply({ embeds: [infoEmbed(`**💰 Richest Members**\n\n${list}`)] });
  }
};
