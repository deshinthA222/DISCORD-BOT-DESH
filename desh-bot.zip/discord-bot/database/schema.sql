-- Per-guild settings (welcome/goodbye, autorole, log channels, prefix, etc.)
CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id TEXT PRIMARY KEY,
  prefix TEXT DEFAULT '!',
  autorole_id TEXT,
  welcome_channel_id TEXT,
  welcome_message TEXT,
  goodbye_channel_id TEXT,
  goodbye_message TEXT,
  mod_log_channel_id TEXT,
  join_log_channel_id TEXT,
  ticket_category_id TEXT,
  ticket_log_channel_id TEXT,
  level_up_channel_id TEXT
);

-- Warnings
CREATE TABLE IF NOT EXISTS warnings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  moderator_id TEXT NOT NULL,
  reason TEXT,
  created_at INTEGER NOT NULL
);

-- Leveling / XP
CREATE TABLE IF NOT EXISTS levels (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 0,
  last_xp_at INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, user_id)
);

-- Economy
CREATE TABLE IF NOT EXISTS economy (
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  balance INTEGER DEFAULT 0,
  bank INTEGER DEFAULT 0,
  last_daily INTEGER DEFAULT 0,
  last_work INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, user_id)
);

-- Tickets
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  claimed_by TEXT,
  status TEXT DEFAULT 'open',
  created_at INTEGER NOT NULL,
  closed_at INTEGER
);

-- Giveaways
CREATE TABLE IF NOT EXISTS giveaways (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  message_id TEXT NOT NULL,
  prize TEXT NOT NULL,
  winners_count INTEGER DEFAULT 1,
  host_id TEXT NOT NULL,
  ends_at INTEGER NOT NULL,
  ended INTEGER DEFAULT 0,
  required_role_id TEXT
);

-- Giveaway entries
CREATE TABLE IF NOT EXISTS giveaway_entries (
  giveaway_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  PRIMARY KEY (giveaway_id, user_id)
);

-- Reaction roles
CREATE TABLE IF NOT EXISTS reaction_roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  message_id TEXT NOT NULL,
  emoji TEXT NOT NULL,
  role_id TEXT NOT NULL
);
