const db = require("../database/db");

function getAccount(guildId, userId) {
  let row = db.prepare("SELECT * FROM economy WHERE guild_id = ? AND user_id = ?").get(guildId, userId);
  if (!row) {
    db.prepare("INSERT INTO economy (guild_id, user_id, balance, bank) VALUES (?, ?, 0, 0)").run(guildId, userId);
    row = { guild_id: guildId, user_id: userId, balance: 0, bank: 0, last_daily: 0, last_work: 0 };
  }
  return row;
}

function updateBalance(guildId, userId, delta) {
  getAccount(guildId, userId);
  db.prepare("UPDATE economy SET balance = balance + ? WHERE guild_id = ? AND user_id = ?").run(
    delta,
    guildId,
    userId
  );
}

module.exports = { getAccount, updateBalance };
