const { PermissionFlagsBits } = require("discord.js");

/**
 * Checks whether a guild member has all the given permission flags.
 * @param {import('discord.js').GuildMember} member
 * @param {bigint[]} flags
 */
function hasPermissions(member, flags = []) {
  return flags.every((flag) => member.permissions.has(flag));
}

/**
 * Checks role hierarchy: can `executor` act on `target`?
 */
function canModerate(executor, target) {
  if (!target) return true;
  if (target.id === executor.id) return false;
  if (target.id === executor.guild.ownerId) return false;
  return executor.roles.highest.position > target.roles.highest.position;
}

module.exports = { hasPermissions, canModerate, PermissionFlagsBits };
