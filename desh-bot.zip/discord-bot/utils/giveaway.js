const db = require("../database/db");
const { infoEmbed } = require("./embeds");

async function endGiveaway(client, giveaway) {
  const entries = db
    .prepare("SELECT user_id FROM giveaway_entries WHERE giveaway_id = ?")
    .all(giveaway.id);

  db.prepare("UPDATE giveaways SET ended = 1 WHERE id = ?").run(giveaway.id);

  const channel = await client.channels.fetch(giveaway.channel_id).catch(() => null);
  if (!channel) return [];

  const message = await channel.messages.fetch(giveaway.message_id).catch(() => null);

  if (entries.length === 0) {
    if (message) await channel.send({ embeds: [infoEmbed(`🎁 **${giveaway.prize}** giveaway ended — no valid entries.`)] });
    return [];
  }

  const pool = [...entries];
  const winners = [];
  const winnerCount = Math.min(giveaway.winners_count, pool.length);
  for (let i = 0; i < winnerCount; i++) {
    const idx = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(idx, 1)[0].user_id);
  }

  const mentionList = winners.map((id) => `<@${id}>`).join(", ");
  await channel.send({
    embeds: [infoEmbed(`🎉 Congratulations ${mentionList}! You won **${giveaway.prize}**!`)]
  });

  return winners;
}

module.exports = { endGiveaway };
