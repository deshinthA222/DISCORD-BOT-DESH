const { EmbedBuilder } = require("discord.js");
const config = require("../config");

function baseEmbed(color = config.colors.primary) {
  return new EmbedBuilder()
    .setColor(color)
    .setFooter({ text: config.brand.footer })
    .setTimestamp();
}

function successEmbed(description) {
  return baseEmbed(config.colors.success).setDescription(`✅ ${description}`);
}

function errorEmbed(description) {
  return baseEmbed(config.colors.danger).setDescription(`❌ ${description}`);
}

function infoEmbed(description) {
  return baseEmbed(config.colors.primary).setDescription(description);
}

module.exports = { baseEmbed, successEmbed, errorEmbed, infoEmbed };
