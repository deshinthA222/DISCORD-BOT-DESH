const db = require("../database/db");

module.exports = {
  name: "messageReactionAdd",
  async execute(reaction, user) {
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch().catch(() => {});

    const emojiKey = reaction.emoji.id ? `<:${reaction.emoji.name}:${reaction.emoji.id}>` : reaction.emoji.name;

    const binding = db
      .prepare("SELECT * FROM reaction_roles WHERE message_id = ? AND emoji = ?")
      .get(reaction.message.id, emojiKey);
    if (!binding) return;

    const guild = reaction.message.guild;
    const member = await guild.members.fetch(user.id).catch(() => null);
    const role = guild.roles.cache.get(binding.role_id);
    if (member && role) await member.roles.add(role).catch(() => {});
  }
};
