const db = require("../database/db");
const { infoEmbed } = require("../utils/embeds");

module.exports = {
  name: "guildMemberRemove",
  async execute(member) {
    const settings = db
      .prepare("SELECT * FROM guild_settings WHERE guild_id = ?")
      .get(member.guild.id);
    if (!settings) return;

    if (settings.goodbye_channel_id) {
      const channel = member.guild.channels.cache.get(settings.goodbye_channel_id);
      if (channel) {
        const text = (settings.goodbye_message || "{user} has left {server}.")
          .replace("{user}", member.user.tag)
          .replace("{server}", member.guild.name);
        channel.send({ embeds: [infoEmbed(text)] }).catch(() => {});
      }
    }

    if (settings.join_log_channel_id) {
      const logChannel = member.guild.channels.cache.get(settings.join_log_channel_id);
      if (logChannel) {
        logChannel
          .send({ embeds: [infoEmbed(`📤 **${member.user.tag}** left the server.`)] })
          .catch(() => {});
      }
    }
  }
};
