const db = require("../database/db");
const { infoEmbed } = require("../utils/embeds");

module.exports = {
  name: "guildMemberAdd",
  async execute(member) {
    const settings = db
      .prepare("SELECT * FROM guild_settings WHERE guild_id = ?")
      .get(member.guild.id);
    if (!settings) return;

    // Autorole
    if (settings.autorole_id) {
      const role = member.guild.roles.cache.get(settings.autorole_id);
      if (role) await member.roles.add(role).catch(() => {});
    }

    // Welcome message
    if (settings.welcome_channel_id) {
      const channel = member.guild.channels.cache.get(settings.welcome_channel_id);
      if (channel) {
        const text = (settings.welcome_message || "Welcome {user} to {server}!")
          .replace("{user}", `${member}`)
          .replace("{server}", member.guild.name);
        channel.send({ embeds: [infoEmbed(text)] }).catch(() => {});
      }
    }

    // Join log
    if (settings.join_log_channel_id) {
      const logChannel = member.guild.channels.cache.get(settings.join_log_channel_id);
      if (logChannel) {
        const accountAgeDays = Math.floor((Date.now() - member.user.createdTimestamp) / 86400000);
        logChannel
          .send({
            embeds: [
              infoEmbed(
                `📥 **${member.user.tag}** joined.\nAccount age: ${accountAgeDays} days\nAccount created: <t:${Math.floor(
                  member.user.createdTimestamp / 1000
                )}:F>`
              )
            ]
          })
          .catch(() => {});
      }
    }
  }
};
