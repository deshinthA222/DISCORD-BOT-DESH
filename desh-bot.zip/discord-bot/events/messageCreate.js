const db = require("../database/db");
const config = require("../config");
const { infoEmbed } = require("../utils/embeds");

function xpForLevel(level) {
  return 5 * level * level + 50 * level + 100;
}

module.exports = {
  name: "messageCreate",
  async execute(message) {
    if (message.author.bot || !message.guild) return;

    const guildId = message.guild.id;
    const userId = message.author.id;
    const now = Date.now();

    let row = db
      .prepare("SELECT * FROM levels WHERE guild_id = ? AND user_id = ?")
      .get(guildId, userId);

    if (!row) {
      db.prepare(
        "INSERT INTO levels (guild_id, user_id, xp, level, last_xp_at) VALUES (?, ?, 0, 0, 0)"
      ).run(guildId, userId);
      row = { xp: 0, level: 0, last_xp_at: 0 };
    }

    const cooldownMs = config.levels.xpCooldownSec * 1000;
    if (now - row.last_xp_at < cooldownMs) return;

    const [min, max] = config.levels.xpPerMessage;
    const gainedXp = Math.floor(Math.random() * (max - min + 1)) + min;
    const newXp = row.xp + gainedXp;
    let newLevel = row.level;

    if (newXp >= xpForLevel(newLevel)) {
      newLevel += 1;

      const settings = db
        .prepare("SELECT level_up_channel_id FROM guild_settings WHERE guild_id = ?")
        .get(guildId);
      const channel = settings?.level_up_channel_id
        ? message.guild.channels.cache.get(settings.level_up_channel_id)
        : message.channel;

      channel
        ?.send({
          embeds: [infoEmbed(`🎉 ${message.author} leveled up to **level ${newLevel}**!`)]
        })
        .catch(() => {});
    }

    db.prepare(
      "UPDATE levels SET xp = ?, level = ?, last_xp_at = ? WHERE guild_id = ? AND user_id = ?"
    ).run(newXp, newLevel, now, guildId, userId);
  }
};
