const { errorEmbed } = require("../utils/embeds");

module.exports = {
  name: "interactionCreate",
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction, client);
      } catch (err) {
        console.error(`[ERROR] /${interaction.commandName}:`, err);
        const payload = { embeds: [errorEmbed("Something went wrong running that command.")], ephemeral: true };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(payload).catch(() => {});
        } else {
          await interaction.reply(payload).catch(() => {});
        }
      }
      return;
    }

    // Button interactions (tickets, giveaways, reaction roles) route by customId prefix
    if (interaction.isButton()) {
      const [namespace] = interaction.customId.split(":");
      const handler = client.buttonHandlers?.get(namespace);
      if (handler) {
        try {
          await handler(interaction, client);
        } catch (err) {
          console.error(`[ERROR] button ${interaction.customId}:`, err);
        }
      }
    }
  }
};
