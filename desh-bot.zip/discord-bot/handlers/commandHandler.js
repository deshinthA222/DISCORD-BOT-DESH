const fs = require("fs");
const path = require("path");

/**
 * Recursively loads all command files from /commands into client.commands
 */
function loadCommands(client) {
  const commandsPath = path.join(__dirname, "..", "commands");
  const folders = fs.readdirSync(commandsPath);

  for (const folder of folders) {
    const folderPath = path.join(commandsPath, folder);
    if (!fs.statSync(folderPath).isDirectory()) continue;

    const files = fs.readdirSync(folderPath).filter((f) => f.endsWith(".js"));
    for (const file of files) {
      const command = require(path.join(folderPath, file));
      if (!command?.data || !command?.execute) {
        console.warn(`[WARN] Skipping ${file}: missing "data" or "execute"`);
        continue;
      }
      client.commands.set(command.data.name, command);
    }
  }

  console.log(`[COMMANDS] Loaded ${client.commands.size} commands.`);
}

module.exports = { loadCommands };
