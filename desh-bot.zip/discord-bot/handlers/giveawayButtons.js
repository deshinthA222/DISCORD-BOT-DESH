const db = require("../database/db");
const { errorEmbed } = require("../utils/embeds");

async function handleGiveawayButton(interaction) {
  const action = interaction.customId.split(":")[1];
  if (action !== "enter") return;

  const giveaway = db
    .prepare("SELECT * FROM giveaways WHERE message_id = ? AND ended = 0")
    .get(interaction.message.id);

  if (!giveaway) {
    return interaction.reply({ embeds: [errorEmbed("This giveaway has ended.")], ephemeral: true });
  }

  if (giveaway.required_role_id && !interaction.member.roles.cache.has(giveaway.required_role_id)) {
    return interaction.reply({
      embeds: [errorEmbed(`You need <@&${giveaway.required_role_id}> to enter this giveaway.`)],
      ephemeral: true
    });
  }

  const existing = db
    .prepare("SELECT * FROM giveaway_entries WHERE giveaway_id = ? AND user_id = ?")
    .get(giveaway.id, interaction.user.id);

  if (existing) {
    db.prepare("DELETE FROM giveaway_entries WHERE giveaway_id = ? AND user_id = ?").run(
      giveaway.id,
      interaction.user.id
    );
  } else {
    db.prepare("INSERT INTO giveaway_entries (giveaway_id, user_id) VALUES (?, ?)").run(
      giveaway.id,
      interaction.user.id
    );
  }

  const count = db
    .prepare("SELECT COUNT(*) AS c FROM giveaway_entries WHERE giveaway_id = ?")
    .get(giveaway.id).c;

  const [row] = interaction.message.components;
  const button = row.components[0];
  const updatedButton = {
    type: 2,
    style: button.style,
    label: `Enter (${count})`,
    emoji: { name: "🎉" },
    custom_id: "giveaway:enter"
  };

  await interaction.update({ components: [{ type: 1, components: [updatedButton] }] });

  return interaction.followUp({
    content: existing ? "You left the giveaway." : "You entered the giveaway! 🎉",
    ephemeral: true
  });
}

module.exports = { handleGiveawayButton };
