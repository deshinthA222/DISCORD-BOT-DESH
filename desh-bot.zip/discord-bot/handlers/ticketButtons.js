const {
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const db = require("../database/db");
const config = require("../config");
const { successEmbed, errorEmbed, infoEmbed } = require("../utils/embeds");

async function handleTicketButton(interaction) {
  const action = interaction.customId.split(":")[1];

  if (action === "open") {
    const existing = db
      .prepare("SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'")
      .get(interaction.guild.id, interaction.user.id);

    if (existing) {
      return interaction.reply({
        embeds: [errorEmbed(`You already have an open ticket: <#${existing.channel_id}>`)],
        ephemeral: true
      });
    }

    let category = interaction.guild.channels.cache.find(
      (c) => c.name === config.tickets.categoryName && c.type === ChannelType.GuildCategory
    );
    if (!category) {
      category = await interaction.guild.channels.create({
        name: config.tickets.categoryName,
        type: ChannelType.GuildCategory
      });
    }

    const channel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.username}`,
      type: ChannelType.GuildText,
      parent: category.id,
      permissionOverwrites: [
        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
          id: interaction.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
        },
        {
          id: interaction.client.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
        }
      ]
    });

    db.prepare(
      "INSERT INTO tickets (guild_id, channel_id, user_id, status, created_at) VALUES (?, ?, ?, 'open', ?)"
    ).run(interaction.guild.id, channel.id, interaction.user.id, Date.now());

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("ticket:claim").setLabel("Claim").setStyle(ButtonStyle.Secondary).setEmoji("🙋"),
      new ButtonBuilder().setCustomId("ticket:close").setLabel("Close").setStyle(ButtonStyle.Danger).setEmoji("🔒")
    );

    await channel.send({
      embeds: [infoEmbed(`Welcome ${interaction.user}! Support will be with you shortly.`)],
      components: [row]
    });

    return interaction.reply({ embeds: [successEmbed(`Ticket created: ${channel}`)], ephemeral: true });
  }

  if (action === "claim") {
    const ticket = db
      .prepare("SELECT * FROM tickets WHERE channel_id = ? AND status = 'open'")
      .get(interaction.channel.id);
    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed("This isn't an active ticket channel.")], ephemeral: true });
    }

    db.prepare("UPDATE tickets SET claimed_by = ? WHERE id = ?").run(interaction.user.id, ticket.id);
    return interaction.reply({ embeds: [successEmbed(`Ticket claimed by ${interaction.user}.`)] });
  }

  if (action === "close") {
    const ticket = db
      .prepare("SELECT * FROM tickets WHERE channel_id = ? AND status = 'open'")
      .get(interaction.channel.id);
    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed("This isn't an active ticket channel.")], ephemeral: true });
    }

    db.prepare("UPDATE tickets SET status = 'closed', closed_at = ? WHERE id = ?").run(Date.now(), ticket.id);

    await interaction.reply({ embeds: [infoEmbed("🔒 Closing this ticket in 5 seconds...")] });
    setTimeout(() => {
      interaction.channel.delete().catch(() => {});
    }, 5000);
  }
}

module.exports = { handleTicketButton };
